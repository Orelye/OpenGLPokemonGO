// TP Corrige avec ajout de la gestion des textures
// For Code::Blocks 20 or higher (gcc/g++ x64)
// Date: 2022
// Using SDL, SDL OpenGL and standard IO
#include <iostream>
#include <cmath>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_opengl.h>
#include <GL/GLU.h>
#include <stdlib.h>
#include <time.h>

// Module for space geometry
#include "geometry.h"
// Module for generating and rendering forms
#include "forms.h"


/***************************************************************************/
/* Constants and functions declarations                                    */
/***************************************************************************/
// Screen dimension constants
const int SCREEN_WIDTH = 1024;
const int SCREEN_HEIGHT = 768;
const Point DEPART_POKEBALL = Point(8,2.5,0);
const Point DEPART_POKEMON = Point(0,3,0);
const Point DEPART_CAMERA = Point(DEPART_POKEBALL.x+10,DEPART_POKEBALL.y+2,DEPART_POKEBALL.z);

// Max number of forms : static allocation
const int MAX_FORMS_NUMBER = 10;

// Animation actualization delay (in ms) => 100 updates per second
const Uint32 ANIM_DELAY = 10;

// Render actualization delay 40 (in ms) => 25 updates per second
const Uint32 FRAME_DELAY = 40;


// Starts up SDL, creates window, and initializes OpenGL
bool init(SDL_Window** window, SDL_GLContext* context);

// Initializes matrices and clear color
bool initGL();

// Updating forms for animation
void update(Form* formlist[MAX_FORMS_NUMBER], double delta_t);

// Renders scene to the screen
void render(Form* formlist[MAX_FORMS_NUMBER], const Point &cam_pos, double angle);

// Frees media and shuts down SDL
void close(SDL_Window** window);


Sphere* creationPokemon(Animation sphAnim, GLuint texture){
    Sphere* pokemon2 = NULL;
    pokemon2 = new Sphere(1, WHITE, "pokemon");
    sphAnim.setPos(DEPART_POKEMON);
    sphAnim.setAccel(Vector(0,0,0));
    sphAnim.setSpeed(Vector(0,0,0));
    pokemon2->setAnim(sphAnim);
    pokemon2->setTexture(texture);
    pokemon2->getAnim().setPhi(15);
    return pokemon2;
}

Sphere* creationPokeball(Animation sphAnim, GLuint texture){
    Sphere* pokeball = NULL;
    pokeball = new Sphere(0.2, WHITE, "pokeball");
    sphAnim.setPhi(0); // angle en degre
    sphAnim.setTheta(0); // angle en degre
    sphAnim.setPos(DEPART_POKEBALL);
    sphAnim.setAccel(Vector(0,0,0));
    sphAnim.setSpeed(Vector(0,0,0));
    pokeball->setAnim(sphAnim);
    pokeball->setTexture(texture);
    return pokeball;
}

Arrow* creationArrow(double powerGauge, double pokeballZ){
    return new Arrow(DEPART_POKEBALL,Point(DEPART_POKEBALL.x - powerGauge/3, DEPART_POKEBALL.y + powerGauge/3, pokeballZ));
}

// Creates a texture into graphic memory from an image file and assign it a
// unique ID, inside textureID
// returns 0 if all went fine, a negative value otherwise
int createTextureFromImage (const char* filename, GLuint* textureID);


/***************************************************************************/
/* Functions implementations                                               */
/***************************************************************************/
bool init(SDL_Window** window, SDL_GLContext* context)
{
    // Initialization flag
    bool success = true;

    // Initialize SDL
    if(SDL_Init(SDL_INIT_VIDEO) < 0)
    {
        std::cerr << "SDL could not initialize! SDL Error: " << SDL_GetError() << std::endl;
        success = false;
    }
    else
    {
        // Use OpenGL 2.1
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 2);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);

        // Create window
        *window = SDL_CreateWindow( "TP intro OpenGL / SDL 2", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_OPENGL | SDL_WINDOW_SHOWN );
        if( *window == NULL )
        {
            std::cerr << "Window could not be created! SDL Error: " << SDL_GetError() << std::endl;
            success = false;
        }
        else
        {
            // Create context
            *context = SDL_GL_CreateContext(*window);
            if( *context == NULL )
            {
                std::cerr << "OpenGL context could not be created! SDL Error: " << SDL_GetError() << std::endl;
                success = false;
            }
            else
            {
                // Use Vsync
                if(SDL_GL_SetSwapInterval(1) < 0)
                {
                    std::cerr << "Warning: Unable to set VSync! SDL Error: " << SDL_GetError() << std::endl;
                }

                // Initialize OpenGL
                if( !initGL() )
                {
                    std::cerr << "Unable to initialize OpenGL!"  << std::endl;
                    success = false;
                }
            }
        }
    }

    return success;
}

bool initGL()
{
    bool success = true;
    GLenum error = GL_NO_ERROR;

    // Initialize Projection Matrix
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    // Set the viewport : use all the window to display the rendered scene
    glViewport(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    // Fix aspect ratio and depth clipping planes
    gluPerspective(40.0, (GLdouble)SCREEN_WIDTH/SCREEN_HEIGHT, 1.0, 100.0);

    // Initialize Modelview Matrix
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // Initialize clear color : black with no transparency
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f );

    // Activate Z-Buffer
    glEnable(GL_DEPTH_TEST);


    // Lighting basic configuration and activation
    const GLfloat light_ambient[]  = { 0.3f, 0.3f, 0.3f, 1.0f };
    const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
    const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
    const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

    const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
    const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
    const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
    const GLfloat high_shininess[] = { 100.0f };

    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);
    //glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);


    // Check for error
    error = glGetError();
    if( error != GL_NO_ERROR )
    {
        std::cerr << "Error initializing OpenGL!  " << gluErrorString( error ) << std::endl;
        success = false;
    }

    return success;
}

void update(Form* formlist[MAX_FORMS_NUMBER], double delta_t)
{
    // Update the list of forms
    unsigned short i = 0;
    while(formlist[i] != NULL)
    {
        formlist[i]->update(delta_t);
        i++;
    }
}

void render(Form* formlist[MAX_FORMS_NUMBER], const Point &cam_pos, double angle)
{
    // Clear color buffer and Z-Buffer
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Initialize Modelview Matrix
    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();

    // Set the camera position and parameters
    gluLookAt(cam_pos.x,cam_pos.y,cam_pos.z, 0.0,0.0,0.0, 0.0,1.0,0.0);
    // Isometric view
    glRotated(angle, 0, 1, 0);
    //glRotated(angle_phi, 0,0, 1);
    //glTranslated(0, -1, 0);
    // X, Y and Z axis

    // X, Y and Z axis
    glPushMatrix(); // Preserve the camera viewing point for further forms
    // Render the coordinates system
    glBegin(GL_LINES);
    {
        glColor3f(1.0f, 0.0f, 0.0f);
        glVertex3i(0, 0, 0);
        glVertex3i(1, 0, 0);
        glColor3f(0.0f, 1.0f, 0.0f);
        glVertex3i(0, 0, 0);
        glVertex3i(0, 1, 0);
        glColor3f(0.0f, 0.0f, 1.0f);
        glVertex3i(0, 0, 0);
        glVertex3i(0, 0, 1);
    }
    glEnd();
    glPopMatrix(); // Restore the camera viewing point for next object

    // Render the list of forms
    unsigned short i = 0;
    while(formlist[i] != NULL)
    {
        glPushMatrix(); // Preserve the camera viewing point for further forms
        formlist[i]->render();
        glPopMatrix(); // Restore the camera viewing point for next object
        i++;
    }
}

void close(SDL_Window** window)
{
    //Destroy window
    SDL_DestroyWindow(*window);
    *window = NULL;

    //Quit SDL subsystems
    SDL_Quit();
}

int createTextureFromImage (const char* filename, GLuint* textureID)
{
    SDL_Surface *imgSurface = IMG_Load(filename);
    if (imgSurface == NULL)
    {
        std::cerr << "Failed to load texture image: " << filename << std::endl;
        return -1;
    }
    else
    {
        // Work out what format to tell glTexImage2D to use...
        int mode;
        if (imgSurface->format->BytesPerPixel == 3)   // RGB 24bit
        {
            mode = GL_RGB;
        }
        else if (imgSurface->format->BytesPerPixel == 4)     // RGBA 32bit
        {
            mode = GL_RGBA;
        }
        else
        {
            SDL_FreeSurface(imgSurface);
            std::cerr << "Unable to detect the image color format of: " << filename << std::endl;
            return -2;
        }
        // create one texture name
        glGenTextures(1, textureID);

        // tell opengl to use the generated texture name
        glBindTexture(GL_TEXTURE_2D, *textureID);

        // this reads from the sdl imgSurface and puts it into an openGL texture
        glTexImage2D(GL_TEXTURE_2D, 0, mode, imgSurface->w, imgSurface->h, 0, mode, GL_UNSIGNED_BYTE, imgSurface->pixels);

        // these affect how this texture is drawn later on...
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

        // clean up
        SDL_FreeSurface(imgSurface);
        return 0;
    }
}

/***************************************************************************/
/* MAIN Function                                                           */
/***************************************************************************/
int main(int argc, char* args[])
{

    Uint32 startTimer = 0;
    int x2 = 0, y2 = 0;
    bool startThrown = false;


    glDisable(GL_LIGHTING);
    glDisable(GL_LIGHT0);
    // The window we'll be rendering to
    SDL_Window* gWindow = NULL;

    // OpenGL context
    SDL_GLContext gContext;


    // Start up SDL and create window
    if( !init(&gWindow, &gContext))
    {
        std::cerr << "Failed to initialize!" << std::endl;
    }
    else
    {
        // Main loop flag
        bool quit = false;
        Uint32 current_time, previous_time_anim, previous_time_render, elapsed_time_anim, elapsed_time_render;

        // Event handler
        SDL_Event event;

        // Camera position
        double rho = 0;
        Point camera_position;
        // Render the scene

        camera_position = DEPART_CAMERA;

        // Textures creation //////////////////////////////////////////////////////////
        GLuint texturePokeball, textureSmogo, texturePokeballDark, textureSol, textureDecor;
        createTextureFromImage("resources/images/Pokeball.jpg", &texturePokeball);
        createTextureFromImage("resources/images/Smogo.jpg", &textureSmogo);
        createTextureFromImage("resources/images/PokeballDark.jpeg", &texturePokeballDark);
        createTextureFromImage("resources/images/Sol.jfif", &textureSol);
        createTextureFromImage("resources/images/Decor.jpeg", &textureDecor);
        // Textures ready to be enabled (with private member " texture_id" of each form)


        // The forms to render
        Form* forms_list[MAX_FORMS_NUMBER];
        unsigned short number_of_forms = 0, i;
        for (i=0; i<MAX_FORMS_NUMBER; i++)
        {
            forms_list[i] = NULL;
        }

        // Get first "current time"
        previous_time_anim = previous_time_render = SDL_GetTicks();
        int t_impact = 0;   //instant de l'impact pokeball / pokemon

        //bool�ens relatifs aux animations de capture du pokemon
        bool can_shoot = true;     //vrai si l'on peut tirer la pokeball
        bool anim_pokeball = false;     //vrai pendant que la pokeball s'�l�ve
        bool anim_pokemon = false;      //vrai pendant que le pokemon se fait aspirer par la pokeball
        bool hesitation_capture = false;      //vrai pendant que l'on d�cide si le pokemon est captur� ou
        bool anim_chute = false;          //vrai pendant la chute de la pokeball apr�s la capture
        bool capture = false;          //pokemon est capture
        bool pas_capture = false;          //pokemon n'est pas capture
        float powerGauge = 4;
        float pokeballPositionZ = 0;

        //pokeball
        Animation sphAnim;

        Sphere* decor = NULL;
        decor = new Sphere(60, WHITE, "decor");
        sphAnim.setPhi(0); // angle en degre
        sphAnim.setTheta(0); // angle en degre
        sphAnim.setPos(Point(0,3,0));
        sphAnim.setAccel(Vector(0,0,0));
        sphAnim.setSpeed(Vector(0,0,0));
        decor->setAnim(sphAnim);
        decor->setTexture(textureDecor);
        forms_list[number_of_forms] = decor;
        number_of_forms++;

        Sphere* pokeball = creationPokeball(sphAnim, texturePokeball);
        forms_list[number_of_forms] = pokeball;
        number_of_forms++;

        Circle* sol = NULL;
        sol = new Circle(12, WHITE);
        sol->getAnim().setTheta(90);
        forms_list[number_of_forms] = sol;
        sol->setTexture(textureSol);
        number_of_forms++;

        // smogo
        Sphere* pokemon = creationPokemon(sphAnim, textureSmogo);
        forms_list[number_of_forms] = pokemon;
        number_of_forms++;

        Arrow *arrow = creationArrow(powerGauge, pokeballPositionZ);
        forms_list[number_of_forms] = arrow;
        number_of_forms++;


        Point pos_impact = Point(0, 0, 0);      //point sur lequel la pokeball tombe pdt la capture
        Point pos_anim = Point(0, 0, 0);        //point sur lequel la pokeball
        int phase_hestiation = 1;
        double t = 0;

        // While application is running
        bool collision = false;
        bool collisionSol = false;
        bool desactivate_position = false; // D�finir une variable bool�enne pour indiquer si le programme est en pause
        int click_F2=1;
        Point camera_pos_user = camera_position;
        int rho_pos_user = rho;

        while(!quit)
        {
            int rho_F1;
            // Handle events on queue
            while(SDL_PollEvent(&event) != 0)
            {
                int x = 0, y = 0;
                SDL_Keycode key_pressed = event.key.keysym.sym;

                switch(event.type)
                {
                // User requests quit
                case SDL_MOUSEBUTTONDOWN:
                        if (!startThrown)
                        {
                            startThrown= true;
                            SDL_GetMouseState( &x2, &y2 );
                            startTimer = SDL_GetTicks();
                        }
                        break;
                 case SDL_MOUSEBUTTONUP:
                        if (startThrown)
                        {
                            startThrown = false;
                            int newX, newY;
                            SDL_GetMouseState( &newX, &newY );
                            Uint32 stopTime = SDL_GetTicks();
                            float elapsedTime= (stopTime-startTimer)/1000.0f;

                            float vitX = -(newX - x2)/elapsedTime;
                            float vitY = -(newY - y2)/elapsedTime;

                            if(can_shoot){
                                pokeball->getAnim().setPhi(3);
                                pokeball->getAnim().setAccel(Vector(0,-9.81,0));
                                pokeball->getAnim().setSpeed(Vector(-vitY/400, DEPART_POKEBALL.y + vitY/800, vitX/200.0f));
                                can_shoot = false;
                                std::cout << "suppression fleche espace" << std::endl;
                                //supression de la fl�che
                                int index = -1;
                                for (int i = 0; i < MAX_FORMS_NUMBER; i++) {
                                    if (forms_list[i] == arrow) {
                                        index = i;
                                        break;
                                    }
                                }
                            if (index != -1) {
                                delete forms_list[index];
                                forms_list[index] = nullptr;
                            }
                            number_of_forms--;
                            std::cout << "fleche supprimee" << std::endl;
                        }
                        break;
                        }
                        break;
                case SDL_QUIT:
                    quit = true;
                    break;
                case SDL_KEYDOWN:
                    // Handle key pressed with current mouse position
                    SDL_GetMouseState( &x, &y );

                    switch(key_pressed)
                    {
                    // Quit the program when 'q' or Escape keys are pressed
                    case SDLK_ESCAPE:
                        quit = true;
                        break;

                    case SDLK_q:
                        if(desactivate_position==false){
                            rho += 5;
                        }
                        break;
                    case SDLK_d:
                        if(desactivate_position==false){
                            rho -= 5;
                        }
                        break;
                    case SDLK_F1:
                        camera_position=DEPART_CAMERA;
                        // rho=rho_pos_user;
                        desactivate_position=false;
                        rho=rho_F1;
                        break;
                    case SDLK_F2:
                        camera_position=DEPART_CAMERA;
                        // rho=rho_pos_user;
                        std::cout << click_F2;
                        if(desactivate_position==false){
                            rho_F1=rho;
                        }
                        if(click_F2==1){
                            desactivate_position=false;
                            rho=rho_F1;
                            camera_position=Point(DEPART_CAMERA.z,DEPART_CAMERA.y,DEPART_CAMERA.x);
                        }
                        if(click_F2==2){
                            desactivate_position=false;
                            rho=rho_F1;
                            camera_position=Point(-DEPART_CAMERA.x,DEPART_CAMERA.y,DEPART_CAMERA.z);
                        }
                        if(click_F2==3){
                            desactivate_position=false;
                            rho=rho_F1;
                            camera_position=Point(DEPART_CAMERA.z,DEPART_CAMERA.y,-DEPART_CAMERA.x);
                        }
                        if(click_F2==4){
                            desactivate_position=true;
                            rho=rho_F1;
                            click_F2 = 0;
                            camera_position=DEPART_CAMERA;
                        }
                        click_F2 += 1;
                        break;
                    case SDLK_F3:
                        camera_position=Point(0,30,0.000001);
                        //desactivate_position=true;
                        break;
                    case SDLK_RIGHT:
                        pokeballPositionZ -= 0.5;
                        if (pokeballPositionZ < -2.5)
                            pokeballPositionZ = -2.5;
                        break;
                    case SDLK_LEFT:
                        pokeballPositionZ += 0.5;
                        if (pokeballPositionZ > 2.5)
                            pokeballPositionZ = 2.5;
                        break;
                    case SDLK_DOWN:
                        powerGauge -= 0.5f;
                        if (powerGauge < 1)
                            powerGauge = 1;
                        break;
                    case SDLK_UP:
                        powerGauge += 0.5f;
                        if (powerGauge > 10)
                            powerGauge = 10;
                        break;
                    case SDLK_SPACE:
                        if(can_shoot){
                            pokeball->getAnim().setPhi(3);
                            pokeball->getAnim().setAccel(Vector(0,-9.81,0));
                            pokeball->getAnim().setSpeed(Vector(-powerGauge, DEPART_POKEBALL.y + powerGauge/2, pokeballPositionZ));
                            can_shoot = false;
                            std::cout << "suppression fleche espace" << std::endl;
                            //supression de la fl�che
                            int index = -1;
                            for (int i = 0; i < MAX_FORMS_NUMBER; i++) {
                                if (forms_list[i] == arrow) {
                                    index = i;
                                    break;
                                }
                            }
                            if (index != -1) {
                                delete forms_list[index];
                                forms_list[index] = nullptr;
                            }
                            number_of_forms--;
                            std::cout << "fleche supprimee" << std::endl;
                        }
                        break;
                    default:
                        break;
                    }
                    break;
                default:
                    break;
                }
                arrow->changeSize(Point(DEPART_POKEBALL.x - powerGauge/3, DEPART_POKEBALL.y + powerGauge/3, pokeballPositionZ));
            }

            // Update the scene
            current_time = SDL_GetTicks(); // get the elapsed time from SDL initialization (ms)
            elapsed_time_anim = current_time - previous_time_anim;
            elapsed_time_render = current_time - previous_time_render;

            if (elapsed_time_anim > ANIM_DELAY)
            {
                previous_time_anim = current_time;
                update(forms_list, 1e-3 * elapsed_time_anim); // International system units : seconds
                //d�tection de la collision pokemon/pokeball
                Vector ballPoke = Vector(pokemon->getAnim().getPos(), pokeball->getAnim().getPos());
                if ((ballPoke.norm() < pokemon->getRadius() + pokeball->getRadius()) && !anim_pokeball && !anim_pokemon && !anim_chute && !hesitation_capture) {
                    //calcul du vecteur de rebond
                    if (!collision){
                        pokeball->rebond(ballPoke);
                        collision = true;
                        //Declenchement capture :
                        pokeball->getAnim().setAccel(Vector(0,1-pokeball->getAnim().getSpeed().y,0));
                        anim_pokeball = true;   //d�but de l'animation de la pokeball
                    }
                }
                else {
                    collision = false;
                }

                if (anim_pokeball){
                    if (t_impact > 150){
                        pokeball->getAnim().setTheta(0); // angle en degre
                        pokeball->getAnim().setSpeed(Vector(0,0,0));
                        pokeball->getAnim().setAccel(Vector(0,0,0));
                        anim_pokeball = false;  //fin de l'animation de la pokeball
                        anim_pokemon = true;    //d�but de l'animation du pokemon
                        pokemon->getAnim().setSpeed(Vector(pokemon->getAnim().getPos(), pokeball->getAnim().getPos()));
                    }
                }
                else if (anim_pokemon){
                    pokemon->setRadius(pokemon->getRadius()*0.975);  //le pokemon r�duit lentement sa taille pdt l'animation
                    if (t_impact > 235){
                        pokemon->getAnim().setSpeed(Vector(0,0,0));
                        //******disparition du pokemon debut
                        int index = -1;
                        for (int i = 0; i < MAX_FORMS_NUMBER; i++) {
                            if (forms_list[i] == pokemon) {
                                index = i;
                                break;
                            }
                        }
                        if (index != -1) {
                            delete forms_list[index];
                            forms_list[index] = nullptr;
                        }
                        number_of_forms--;
                        //******disparition du pokemon fin*/
                        pokeball->getAnim().setAccel(Vector(0,-29.81,0));
                        anim_pokemon = false;   //fin de l'animation du pokemon
                        anim_chute = true;   //debut de la capture ou non
                    }
                }
                if (pokeball->getAnim().getPos().y < pokeball->getRadius()) {
                    //calcul du vecteur de rebond
                    if (!collisionSol){
                        pokeball->rebond(Vector(0,1,0));
                        collisionSol = true;
                        Vector pokeballSpeed = pokeball->getAnim().getSpeed();
                        if(pokeballSpeed.x == 0 && pokeballSpeed.y < 1 && pokeballSpeed.z == 0){
                            std::cout << "pokeball stoppee" << std::endl;
                            if (anim_chute){
                                hesitation_capture = true;
                                anim_chute = false;
                                pos_impact = pokeball->getAnim().getPos();
                                pos_anim.y = pos_impact.y;
                                t_impact = 0;
                            }
                            pokeball->getAnim().setAccel(Vector(0,0,0));
                            pokeball->getAnim().setSpeed(Vector(0,0,0));
                            pokeball->getAnim().setPos(Point(pokeball->getAnim().getPos().x,pokeball->getRadius(),pokeball->getAnim().getPos().z));
                        }
                    }
                }
                else {
                    collisionSol = false;
                }
                if(hesitation_capture){
                    double vitesse = 0.01;
                    double pi = 3.14159265359;
                    if(phase_hestiation == 1){
                        if (t < 1){
                            pos_anim.x = pos_impact.x + 0.05*cos(pi*t)*sin(pi*t);
                            pos_anim.z = pos_impact.z + 0.05*sin(pi*t)*sin(pi*t);
                            pokeball->getAnim().setPos(pos_anim);
                            t = t + vitesse;
                        }
                        else{
                            t = 0;
                            t_impact = 0;
                            phase_hestiation++;
                        }
                    }
                    if(phase_hestiation == 2 && t_impact > 20){
                        if (t < 1){
                            pos_anim.x = pos_impact.x + 0.07*cos(pi*t)*sin(pi*t);
                            pos_anim.z = pos_impact.z + 0.07*sin(pi*t)*sin(pi*t);
                            pokeball->getAnim().setPos(pos_anim);
                            t = t + vitesse;
                        }
                        else{
                            t = 0;
                            t_impact = 0;
                            phase_hestiation++;
                        }
                    }

                    if(phase_hestiation == 3 && t_impact > 20){
                        if (t < 1){
                            pos_anim.x = pos_impact.x + 0.07*cos(pi*t)*sin(pi*t);
                            pos_anim.z = pos_impact.z + 0.07*sin(pi*t)*sin(pi*t);
                            pokeball->getAnim().setPos(pos_anim);
                            t = t + vitesse;
                        }
                        else{
                            t = 0;
                            t_impact = 0;
                            phase_hestiation++;
                        }
                    }
                    if (t_impact == 50 && phase_hestiation == 4){ //capture ou pas ?
                        srand (time(NULL));
                        if (rand() % 2 == 0){
                            pas_capture = true;
                        }
                        else{
                            capture = true;
                            pokeball->setTexture(texturePokeballDark);
                        }
                        t = 0;
                        phase_hestiation = 1;
                        hesitation_capture = false;
                    }
                }
                else if (abs(pokeball->getAnim().getSpeed().x) < 0.5 && abs(pokeball->getAnim().getSpeed().z) < 0.5 && !anim_pokeball && !anim_pokemon && !anim_chute && !can_shoot && !capture && !pas_capture){
                    pokeball->getAnim().setSpeed(Vector(0,0,0));
                    pokeball->getAnim().setAccel(Vector(0,0,0));
                    pokeball->getAnim().setTheta(0);
                    pokeball->getAnim().setPhi(0);
                    pokeball->getAnim().setPos(DEPART_POKEBALL);
                    arrow = creationArrow(powerGauge, pokeballPositionZ);
                    forms_list[number_of_forms] = arrow;
                    number_of_forms++;
                    can_shoot = true;
                }
                if (capture || pas_capture) {
                    if (t_impact == 150){
                        //pokeball
                        sphAnim.setPhi(0); // angle en degre
                        sphAnim.setTheta(0); // angle en degre
                        sphAnim.setPos(DEPART_POKEBALL);
                        sphAnim.setAccel(Vector(0,0,0));
                        sphAnim.setSpeed(Vector(0,0,0));
                        pokeball->setAnim(sphAnim);
                        pokeball->setTexture(texturePokeball);

                        // smogo
                        pokemon = creationPokemon(sphAnim, textureSmogo);
                        forms_list[number_of_forms] = pokemon;
                        number_of_forms++;
                        pas_capture = false;
                        capture = false;
                        collision = false;
                        can_shoot = true;
                        t_impact = 0;
                        arrow = creationArrow(powerGauge, pokeballPositionZ);
                        forms_list[number_of_forms] = arrow;
                        number_of_forms++;
                    }
                }
                if (pas_capture) {
                    if (t_impact == 60){
                        std::cout << "Pas de capture ..." << std::endl;
                    }
                }
                if (anim_pokeball || anim_pokemon || hesitation_capture || anim_chute || pas_capture || capture){
                    t_impact += 1;
                }
            }



            if (elapsed_time_render > FRAME_DELAY)
            {
                previous_time_render = current_time;
                render(forms_list, camera_position, rho);

                // Update window screen
                SDL_GL_SwapWindow(gWindow);
            }
        }
    }

    // Free resources and close SDL
    close(&gWindow);

    return 0;
}
